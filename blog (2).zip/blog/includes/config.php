<?php
ob_start();
session_start();

//database credentials
define('DBHOST','mysql7.000webhost.com');
define('DBUSER','a2476157_blog');
define('DBPASS','a2476157_blog');
define('DBNAME','a2476157_blog');
//server DB Connection string
/*$db = mysql_connect("mysql7.000webhost.com", "a2476157_blog", "123456") or die("Could not connect to host.");
mysql_select_db("a2476157_blog",$db) or die("Could not find database.");
*/
//local machine connection string
$linkID = mysql_connect("localhost", "root", "Ch@r1ie5817") or die("Could not connect to host.");
mysql_select_db("blog",$linkID) or die("Could not find database.");
//set timezone
date_default_timezone_set('Asia/Kolkata');

//load classes as needed
function __autoload($class) {
   
   $class = strtolower($class);

	//if call from within assets adjust the path
   $classpath = 'classes/class.'.$class . '.php';
   if ( file_exists($classpath)) {
      require_once $classpath;
	} 	
	
	//if call from within admin adjust the path
   $classpath = '../classes/class.'.$class . '.php';
   if ( file_exists($classpath)) {
      require_once $classpath;
	}
	
	//if call from within admin adjust the path
   $classpath = '../../classes/class.'.$class . '.php';
   if ( file_exists($classpath)) {
      require_once $classpath;
	} 		
	 
}

$user = new User($db); 
?>